//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DAS.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_ANALYSTYPE                  129
#define IDD_DIALOG1                     130
#define IDC_CURSOR1                     131
#define IDR_MENU1                       134
#define IDD_DIALOG2                     135
#define IDD_DIALOG3                     136
#define IDD_DIALOG4                     137
#define IDC_Variable_1                  1000
#define IDC_Variable_2                  1001
#define IDC_Variable_3                  1002
#define IDC_MinimumY                    1003
#define IDC_EDIT1                       1004
#define IDC_EDIT_STRING1                1004
#define IDC_BUTTON1                     1005
#define IDC_APPEND                      1005
#define IDC_OVERWRITE                   1006
#define ID_2DGraph                      32771
#define ID_3DGraph                      32773
#define ID_2DGraph_II                   32774
#define ID_2DGraph_III                  32775
#define ID_2DGraph_IV                   32776
#define ID_2DGraph_V                    32777
#define ID_2DGraph_VI                   32778
#define ID_2DGraph_VII                  32779
#define ID_2DGraph_VIII                 32781
#define ID_PROCEED                      32782
#define ID_Parameters                   32785
#define ID_Functions                    32786
#define ID_SLOW_DOWN                    32787
#define ID_SPEED_UP                     32788
#define Quick_Function                  32789
#define ID_ONEDR_STEPBYSTEP             32790
#define ID_STEP_BY_STEP                 32791
#define ID_ONEDR_PD                     32793
#define ID_ONEDR_PD32794                32794
#define ID_IS_HIGH_TO_LOW               32795
#define ID_SELECT1                      32797
#define ID_BUTTON32798                  32798
#define ID_UNSELECT1                    32798
#define ID_VIEW_SMALLERPANNELS          32799
#define ID_VIEW_BIGGERPANNELS           32800
#define ID_SCALE_CHANGESCALE            32801
#define ID_SCALE_CHANGE_SCALE           32802
#define ID_SCALE_DELETE_FIGS            32803
#define ID_SCALE_DELETETHEREST          32804
#define ID_SCALE_DELETE_THE_REST        32805
#define ID_VT_DELETE                    32806
#define ID_SELECT2                      32807
#define ID_SELECT3                      32808
#define ID_SCALE_SELECT2                32809
#define ID_SCALE_SELECT3                32810
#define ID_CONFIG_FILE_SAVE             32811
#define ID_FILE_CLOSE32812              32812
#define ID_FILE_REMEMBER                32813
#define ID_BUTTON32814                  32814
#define ID_ADJUST_SCALE_TO_FIT_DATA     32814
#define ID_DISPLAY_ACQUISION_DISRUPTION 32815
#define ID_VIEW_FLIP                    32816
#define ID_VIEW_FLIP_SIGNAL             32817
#define ID_FILE_SHOW                    32818
#define ID_VIEW_SHOW                    32819

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32820
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
