Version_number: 1.00
GlobalTitle:    Time-Voltage Discriminator

How_many_ROWs: 2
How_many_COLUMNs: 2

0	0
Title:    TVD

5	41	633	371
6	12
-1	-1
NULL
NULL
0.000	2.500	-1.500	1.500
0


1	0
Title:    Signals selected / not selected

5	376	633	706
6	12
-1	-1
NULL
NULL
0.000	1.000	0.000	1.000
0


0	1
Title: NoName
638	41	1266	371
6	12
-1	-1
NULL
NULL
0.000	4000.000	-1.500	1.500
0


1	1
Title: NoName
638	376	1266	706
6	12
-1	-1
NULL
NULL
0.000	4000.000	-1.500	1.500
0


