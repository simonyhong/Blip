//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MOXY.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_ANALYSTYPE                  129
#define IDC_CURSOR1                     131
#define IDD_DIALOG8                     140
#define IDD_DIALOG9                     141
#define IDD_DIALOG10                    142
#define IDD_DIALOG12                    144
#define IDD_DIALOG14                    148
#define IDD_DIALOG1                     149
#define IDC_EDIT2                       1058
#define IDC_MIN_Y                       1058
#define IDC_MAX_Y                       1059
#define IDC_MIN_X                       1060
#define IDC_MAX_X                       1061
#define IDC_EDIT1                       1062
#define IDC_EDIT3                       1063
#define IDC_OVERWRITE                   1072
#define ID_APPEND_FILE                  1073
#define IDC_APPEND_FILE                 1073
#define IDC_CHECK1                      1074
#define IDC_CHECK2                      1075
#define IDC_CHECK3                      1076
#define IDC_CHECK4                      1077
#define IDC_CHECK5                      1078
#define IDC_CHECK6                      1079
#define IDC_CHECK7                      1080
#define IDC_CHECK8                      1081
#define IDC_CHECK9                      1082
#define IDC_CHECK10                     1083
#define ID_CALIBRATE_SCREEN             32773
#define ID_TASK_SCHEDULER               32775
#define ID_2DGraph_VIII                 32781
#define ID_PROCEED                      32782
#define ID_Parameters                   32785
#define ID_Functions                    32786
#define ID_SLOW_DOWN                    32787
#define ID_SPEED_UP                     32788
#define Quick_Function                  32789
#define ID_ONEDR_STEPBYSTEP             32790
#define ID_STEP_BY_STEP                 32791
#define ID_ONEDR_PD                     32793
#define ID_ONEDR_PD32794                32794
#define ID_IS_PD                        32795
#define ID_SMALLER_PANNELS              32797
#define ID_BUTTON32798                  32798
#define ID_BIGGER_PANNELS               32798
#define ID_VIEW_SMALLERPANNELS          32799
#define ID_VIEW_BIGGERPANNELS           32800
#define ID_BUTTON32801                  32801
#define ID_RESET_DISPLAY                32801
#define ID_FILE_CLOSE32802              32802
#define ID_FILE_CLOSE_WRITING           32803
#define ID_FILE_SAVE_RAS                32804
#define ID_BUTTON32805                  32805
#define ID_VT_DISCRIMINATOR             32805
#define ID_LAUNCH_VIS                   32806
#define ID_LAUNCH_RAS                   32807
#define ID_LAUNCH_ANTS                  32808
#define ID_LAUNCH_OSCILLOSCOPE          32809
#define ID_MY_NEW_FIX                   32810
#define ID_CLAS                         32811
#define ID_FILE_REMEMBER                32812
#define ID_BUTTON32813                  32813
#define ID_XCOR                         32813
#define ID_CLOSE_BLIP                   32814
#define ID_BLANK                        32815
#define ID_VIEW_RIGHT                   32816
#define ID_VIEW_RIGHT_CLICK_FIGURE      32817
#define ID_VIEW_VISIBLE                 32818
#define ID_VIEW_VISIBLE_OBJs            32819
#define ID_VIEW_CARTESIAN               32820
#define ID_VIEW_OBJECT                  32821
#define ID_VIEW_OBJECT_PROJECTED        32822
#define ID_VIEW_ANGLE_MONITOR           32823
#define ID_VIEW_CARTESTAN               32824
#define ID_VIRTUAL_ELECTRODE            32825

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         32826
#define _APS_NEXT_CONTROL_VALUE         1084
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
