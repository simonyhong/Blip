//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TAS.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_ANALYSTYPE                  129
#define IDD_DIALOG1                     130
#define IDC_CURSOR1                     131
#define IDD_DIALOG2                     134
#define IDD_DIALOG3                     135
#define IDD_DIALOG13                    147
#define IDD_DIALOG14                    148
#define IDD_DIALOG15                    149
#define IDC_Variable_1                  1000
#define IDC_Variable_2                  1001
#define IDC_Variable_3                  1002
#define IDC_Variable_4                  1005
#define IDC_Variable_5                  1006
#define IDC_Variable_6                  1007
#define IDC_Variable_7                  1008
#define IDC_Variable_8                  1009
#define IDC_Variable_9                  1010
#define IDC_Variable_10                 1011
#define IDC_Variable_11                 1013
#define IDC_Variable_12                 1014
#define IDC_Variable_13                 1015
#define IDC_Variable_14                 1016
#define IDC_Variable_15                 1017
#define IDC_Variable_16                 1018
#define IDC_Variable_17                 1019
#define IDC_CHECK1                      1020
#define IDC_Variable_18                 1021
#define IDC_CHECK2                      1022
#define IDC_CHECK3                      1023
#define IDC_Variable_19                 1025
#define IDC_Variable_20                 1026
#define IDC_Variable_21                 1027
#define IDC_Variable_22                 1028
#define IDC_D2Var1                      1029
#define IDC_D2Var2                      1030
#define IDC_D2Var3                      1031
#define IDC_D3Var1                      1032
#define IDC_D3Var2                      1033
#define IDC_D3Var3                      1034
#define IDC_D3Var4                      1035
#define IDC_D3Var5                      1036
#define IDC_D3Var6                      1037
#define IDC_D3Var7                      1038
#define IDC_D3CHECK1                    1039
#define IDC_D3CHECK2                    1040
#define IDC_Variable_23                 1057
#define IDC_EDIT1                       1062
#define IDC_COMBO1                      1071
#define IDC_OVERWRITE                   1072
#define ID_APPEND_FILE                  1073
#define IDC_APPEND_FILE                 1073
#define IDC_HOW_TO_GENERATE_XY          1074
#define IDC_WAIT_TO_FIXATE              1075
#define IDC_EDIT4                       1076
#define IDC_MINI_DUR_FIX                1076
#define ID_CALIBRATE_SCREEN             32773
#define ID_TASK_SCHEDULER               32775
#define ID_2DGraph_VIII                 32781
#define ID_PAUSE                        32782
#define ID_Parameters                   32785
#define ID_Functions                    32786
#define ID_SLOW_DOWN                    32787
#define ID_SPEED_UP                     32788
#define Quick_Function                  32789
#define ID_ONEDR_STEPBYSTEP             32790
#define ID_STEP_BY_STEP                 32791
#define ID_ONEDR_PD                     32793
#define ID_ONEDR_PD32794                32794
#define ID_IS_PD                        32795
#define ID_SMALLER_PANNELS              32797
#define ID_BUTTON32798                  32798
#define ID_BIGGER_PANNELS               32798
#define ID_VIEW_SMALLERPANNELS          32799
#define ID_VIEW_BIGGERPANNELS           32800
#define ID_BUTTON32801                  32801
#define ID_RESET_DISPLAY                32801
#define ID_FILE_CLOSE32802              32802
#define ID_FILE_CLOSE_WRITING           32803
#define ID_FILE_SAVE_TAS                32804
#define ID_BUTTON32805                  32805
#define ID_VT_DISCRIMINATOR             32805
#define ID_LAUNCH_VIS                   32806
#define ID_LAUNCH_RAS                   32807
#define ID_LAUNCH_ANTS                  32808
#define ID_LAUNCH_OSCILLOSCOPE          32809
#define ID_MY_NEW_FIX                   32810
#define ID_FILE_REMEMBER                32812

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         32813
#define _APS_NEXT_CONTROL_VALUE         1077
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
