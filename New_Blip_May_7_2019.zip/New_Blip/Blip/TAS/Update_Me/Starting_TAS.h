	//CTASDoc* tas_pDoc = GetDocument(); 
	//ASSERT_VALID(tas_pDoc);
	//if(tas_pDoc->tas_bFistTime==1 ){
	//	tas_pDoc->m_pView=this;		m_pDoc=tas_pDoc; 
	//	//RootFileOpen();//Try to open a default root file.
	//	OnTaskScheduler();
	//}