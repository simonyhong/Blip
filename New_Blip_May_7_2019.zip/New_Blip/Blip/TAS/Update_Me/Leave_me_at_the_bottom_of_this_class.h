public:
	void TaskScheduler();
	CTASDoc* GetDocument();
	CTASDoc* m_pDoc;