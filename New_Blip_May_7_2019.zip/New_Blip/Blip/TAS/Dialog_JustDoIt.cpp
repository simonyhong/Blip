// Dialog_JustDoIt.cpp : implementation file
//

#include "stdafx.h"
#include "TAS.h"
#include "Dialog_JustDoIt.h"
#include "afxdialogex.h"


// Dialog_JustDoIt dialog

IMPLEMENT_DYNAMIC(Dialog_JustDoIt, CDialogEx)

Dialog_JustDoIt::Dialog_JustDoIt(CWnd* pParent /*=NULL*/)
	: CDialogEx(Dialog_JustDoIt::IDD, pParent)
{

}

Dialog_JustDoIt::~Dialog_JustDoIt()
{
}

void Dialog_JustDoIt::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(Dialog_JustDoIt, CDialogEx)
END_MESSAGE_MAP()


// Dialog_JustDoIt message handlers
