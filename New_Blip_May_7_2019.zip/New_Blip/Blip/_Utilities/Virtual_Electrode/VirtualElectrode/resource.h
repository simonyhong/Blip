//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Analysis.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_ANALYSTYPE                  129
#define IDD_DIALOG1                     130
#define IDC_CURSOR1                     131
#define IDR_MENU1                       134
#define IDD_DIALOG3                     136
#define IDD_DIALOG4                     137
#define IDD_DIALOG5                     138
#define IDD_DIALOG6                     139
#define IDD_DIALOG7                     140
#define IDD_DIALOG8                     141
#define IDD_ELECTRODE_XYZ               142
#define IDD_DIALOG9                     143
#define IDD_DIALOG10                    144
#define IDD_DIALOG11                    145
#define IDD_Accept_one_Double           145
#define IDD_PITCH_ROLL_YAW              146
#define IDD_DIALOG2                     147
#define IDD_DIALOG12                    148
#define IDC_Variable_1                  1000
#define IDC_Variable_2                  1001
#define IDC_Variable_3                  1002
#define IDC_MinimumY                    1003
#define IDC_EDIT1                       1004
#define IDC_EDIT2                       1005
#define IDC_EDIT3                       1006
#define IDC_EDIT4                       1007
#define IDC_EDIT5                       1008
#define IDC_EDIT6                       1009
#define IDC_EDIT7                       1010
#define IDC_EDIT8                       1011
#define IDC_EDIT9                       1012
#define IDC_EDIT10                      1013
#define IDC_EDIT11                      1014
#define IDC_EDIT12                      1015
#define IDC_EDIT13                      1017
#define IDC_ELECT_X                     1020
#define IDC_IDC_ELECT_Y                 1021
#define IDC_IDC_ELECT_Z                 1022
#define ID_2DGraph                      32771
#define ID_3DGraph                      32773
#define ID_2DGraph_II                   32774
#define ID_2DGraph_III                  32775
#define ID_2DGraph_5                    32776
#define ID_2DGraph_4                    32777
#define ID_2DGraph_VI                   32778
#define ID_2DGraph_VII                  32779
#define ID_2DGraph_VIII                 32781
#define ID_PROCEED                      32782
#define ID_Parameters                   32785
#define ID_Functions                    32786
#define ID_SLOW_DOWN                    32787
#define ID_SPEED_UP                     32788
#define Quick_Function                  32789
#define ID_ONEDR_STEPBYSTEP             32790
#define ID_STEP_BY_STEP                 32791
#define ID_ONEDR_PD                     32793
#define ID_ONEDR_PD32794                32794
#define ID_IS_PD                        32795
#define ID_SMALLER_PANNELS              32797
#define ID_BUTTON32798                  32798
#define ID_BIGGER_PANNELS               32798
#define ID_VIEW_SMALLERPANNELS          32799
#define ID_VIEW_BIGGERPANNELS           32800
#define ID_SCALE_CHANGESCALE            32801
#define ID_SCALE_CHANGE_SCALE           32802
#define ID_SCALE_DELETE_FIGS            32803
#define ID_SCALE_DELETETHEREST          32804
#define ID_SCALE_DELETE_THE_REST        32805
#define ID_FILE_SAVE32806               32806
#define ID_FILE_SAVE_DRAWING            32807
#define ID_RESET_ELECTRODE_TO_0         32808
#define ID_SHOW_000                     32809
#define ID_SELECT                       32810
#define ID_MAKE_POINTS                  32811
#define ID_MAKE_LINE_SEGMENTS           32812
#define ID_EDIT_POINTS                  32813
#define ID_DELETE_OBJ                   32814
#define ID_CROSSHAIR                    32815
#define ID_CROSSHAIR_ON_PIC             32816
#define ID_CONFIG_DIALOG                32817
#define ID_FLIP_X_AXIS                  32818
#define ID_TEXTURE                      32819
#define ID_SHOW_TEXTURE                 32819
#define _BLANK2                         32820
#define SHOW_DRAWING                    32820
#define ID_FILE_REMEMBER                32821
#define ID_ELECTRODE_COORDINATE         32822
#define ID_VIEW_DISTANCEFROMELECTRODE   32823
#define ID_VIEW_DISTANCE_FROM_ELECTRODE 32824
#define ID_BLANK                        32825
#define ID_LOCATE_GRID_ORIGIN           32826
#define ID_TOOLS_RENAME                 32827
#define ID_TOOLS_SET                    32828
#define ID_TOOLS_SET32829               32829
#define ID_TOOLS_SET32830               32830
#define ID_SHOW_GRID                    32831
#define ID_MARKING                      32832

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32833
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
