// Dialog_SaveFirst.cpp : implementation file
//

#include "stdafx.h"
#include "Analysis.h"
#include "Dialog_SaveFirst.h"
#include "afxdialogex.h"


// Dialog_SaveFirst dialog

IMPLEMENT_DYNAMIC(Dialog_SaveFirst, CDialogEx)

Dialog_SaveFirst::Dialog_SaveFirst(CWnd* pParent /*=NULL*/)
	: CDialogEx(Dialog_SaveFirst::IDD, pParent)
{

}

Dialog_SaveFirst::~Dialog_SaveFirst()
{
}

void Dialog_SaveFirst::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(Dialog_SaveFirst, CDialogEx)
END_MESSAGE_MAP()


// Dialog_SaveFirst message handlers
