// ReplaceConfirm.cpp : implementation file
//

#include "stdafx.h"
#include "Analysis.h"
#include "Dialog_ReplaceConfirm.h"
#include "afxdialogex.h"


// CReplaceConfirm dialog

IMPLEMENT_DYNAMIC(CReplaceConfirm, CDialogEx)

CReplaceConfirm::CReplaceConfirm(CWnd* pParent /*=NULL*/)
	: CDialogEx(CReplaceConfirm::IDD, pParent)
{

}

CReplaceConfirm::~CReplaceConfirm()
{
}

void CReplaceConfirm::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CReplaceConfirm, CDialogEx)
END_MESSAGE_MAP()


// CReplaceConfirm message handlers
