//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Analysis.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_ANALYSTYPE                  129
#define IDD_DIALOG1                     130
#define IDC_CURSOR1                     131
#define IDD_DIALOG2                     135
#define IDD_DIALOG3                     136
#define IDC_Variable_1                  1000
#define IDC_Variable_2                  1001
#define IDC_Variable_3                  1002
#define IDC_MinimumY                    1003
#define IDC_EDIT1                       1004
#define IDC_EDIT_STRING1                1004
#define IDC_CHECK1                      1005
#define ID_2DGraph                      32771
#define ID_3DGraph                      32773
#define ID_2DGraph_II                   32774
#define ID_2DGraph_III                  32775
#define ID_2DGraph_IV                   32776
#define ID_2DGraph_V                    32777
#define ID_2DGraph_VI                   32778
#define ID_2DGraph_VII                  32779
#define ID_2DGraph_VIII                 32781
#define ID_PROCEED                      32782
#define ID_Parameters                   32785
#define ID_Functions                    32786
#define ID_SLOW_DOWN                    32787
#define ID_SPEED_UP                     32788
#define Quick_Function                  32789
#define ID_ONEDR_STEPBYSTEP             32790
#define ID_STEP_BY_STEP                 32791
#define ID_ONEDR_PD                     32793
#define ID_ONEDR_PD32794                32794
#define ID_IS_PD                        32795
#define ID_SMALLER_PANNELS              32797
#define ID_BUTTON32798                  32798
#define ID_BIGGER_PANNELS               32798
#define ID_VIEW_SMALLERPANNELS          32799
#define ID_VIEW_BIGGERPANNELS           32800
#define ID_SCALE_CHANGESCALE            32801
#define ID_SCALE_CHANGE_SCALE           32802
#define ID_SCALE_DELETETHEREST          32804

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32806
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
